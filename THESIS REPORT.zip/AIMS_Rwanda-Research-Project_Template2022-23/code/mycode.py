# This program prints hello

import Scipy as S

if __name__ == "__main__":
	print "hello"
